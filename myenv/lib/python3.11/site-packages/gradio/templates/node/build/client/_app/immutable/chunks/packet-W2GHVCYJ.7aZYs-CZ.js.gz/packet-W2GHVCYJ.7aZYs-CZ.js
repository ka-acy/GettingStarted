import { P, a } from "./mermaid-parser.core.QyhIjRMw.js";
export {
  P as PacketModule,
  a as createPacketServices
};
