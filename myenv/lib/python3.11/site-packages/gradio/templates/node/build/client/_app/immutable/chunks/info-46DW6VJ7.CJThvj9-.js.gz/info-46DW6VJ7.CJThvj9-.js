import { I, c } from "./mermaid-parser.core.QyhIjRMw.js";
export {
  I as InfoModule,
  c as createInfoServices
};
