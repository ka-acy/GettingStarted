import { E, b, d, c, g, i, l, e, m, p, a, s, t } from "./2.ChNy08-U.js";
export {
  E as Embed,
  b as all_common_keys,
  d as changeLocale,
  c as create_components,
  g as get_initial_locale,
  i as is_translation_metadata,
  l as language_choices,
  e as load_translations,
  m as mount_css,
  p as prefix_css,
  a as process_langs,
  s as setupi18n,
  t as translate_if_needed
};
